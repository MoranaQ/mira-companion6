# Mira - Cute Anime Companion with Autonomous Journaling & Google Gemini

This is the complete native Android project for Mira.
- Preconfigured with your Google Gemini API Key
- Autonomous Self-Journaling Worker
- Floating Overlay Service (SYSTEM_ALERT_WINDOW)
- App Navigation Manager for WhatsApp, YouTube, Maps, etc.
- Jetpack Compose with Pastel Lavender & Pink UI
- Full Arabic Right-To-Left (RTL) support

## How to build APK:
1. Open this folder in Android Studio.
2. Wait for Gradle Sync to finish.
3. Click: Build > Build Bundle(s) / APK(s) > Build APK(s)
4. Your APK will be at: app/build/outputs/apk/debug/app-debug.apk
